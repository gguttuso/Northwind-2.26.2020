﻿using System;
using System.Linq;
using Northwind.Models;

namespace Blogs.Models
{
    public interface IProductsRepository
    {
        IQueryable<Product> Products { get; }
        IQueryable<Category> Categories { get; }

    }
}