﻿using System;
using System.Linq;
using Northwind.Models;

namespace Blogs.Models
{
    public class EFProductsRepository : IProductsRepository
    {
        // the repository class depends on the BloggingContext service
        // which was registered at application startup
        private NorthwindContext context;
        public EFProductsRepository(NorthwindContext ctx)
        {
            context = ctx;
        }
        // create IQueryable for Blogs & Posts
        public IQueryable<Product> Products => context.Products;
        public IQueryable<Category> Categories => context.Categories;

    }
}